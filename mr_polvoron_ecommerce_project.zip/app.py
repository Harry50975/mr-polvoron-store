
from flask import Flask, render_template, request, redirect, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "mr_polvoron_secret"

app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///database.db"
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50))
    email = db.Column(db.String(120))
    password = db.Column(db.String(200))

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    description = db.Column(db.Text)
    price = db.Column(db.Float)
    sku = db.Column(db.String(50))
    stock = db.Column(db.Integer)
    image = db.Column(db.String(200))

@app.route("/")
def home():
    products = Product.query.limit(6)
    return render_template("home.html", products=products)

@app.route("/shop")
def shop():
    products = Product.query.all()
    return render_template("shop.html", products=products)

@app.route("/product/<int:id>")
def product(id):
    product = Product.query.get(id)
    return render_template("product.html", product=product)

@app.route("/add_to_cart/<int:id>")
def add_to_cart(id):
    cart = session.get("cart", {})
    if str(id) in cart:
        cart[str(id)] += 1
    else:
        cart[str(id)] = 1
    session["cart"] = cart
    return redirect("/cart")

@app.route("/cart")
def cart():
    cart = session.get("cart", {})
    items = []
    total = 0
    for id, qty in cart.items():
        product = Product.query.get(int(id))
        subtotal = product.price * qty
        items.append({"product": product, "qty": qty, "subtotal": subtotal})
        total += subtotal
    return render_template("cart.html", items=items, total=total)

@app.route("/checkout", methods=["GET","POST"])
def checkout():
    if request.method == "POST":
        session["cart"] = {}
        return redirect("/confirmation")
    return render_template("checkout.html")

@app.route("/confirmation")
def confirmation():
    return render_template("confirmation.html")

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        password = generate_password_hash(request.form["password"])
        user = User(username=request.form["username"], email=request.form["email"], password=password)
        db.session.add(user)
        db.session.commit()
        return redirect("/login")
    return render_template("register.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        user = User.query.filter_by(email=request.form["email"]).first()
        if user and check_password_hash(user.password, request.form["password"]):
            session["user"] = user.id
            return redirect("/dashboard")
    return render_template("login.html")

@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
        if Product.query.count() == 0:
            products = [
                Product(name="Classic Polvoron", description="Traditional buttery polvoron.", price=140, sku="MP001", stock=100, image="https://via.placeholder.com/200"),
                Product(name="Biscoff Polvoron", description="Biscoff flavored premium polvoron.", price=165, sku="MP002", stock=80, image="https://via.placeholder.com/200"),
                Product(name="Matcha Polvoron", description="Matcha infused polvoron.", price=150, sku="MP003", stock=90, image="https://via.placeholder.com/200"),
            ]
            for p in products:
                db.session.add(p)
            db.session.commit()
    app.run(debug=True)
